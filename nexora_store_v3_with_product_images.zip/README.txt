# Nexora — polished storefront starter

Open `index.html` to view the site locally, or upload the files to a free static host.

The product catalog is intentionally a demo. Before launch, verify supplier costs, shipping times, returns, product quality, and your legal/store policies.

Stripe:
This storefront currently has a demo checkout button. Real Stripe payments require a secure server-side Stripe Checkout integration and an appropriate Stripe account. If the store owner is under 18, Stripe account setup requires an adult representative.

Files:
- index.html
- style.css
- script.js
- README.txt

Product visuals: the six product images are original SVG illustrations created for this demo, so you don't need to rely on third-party product photos. Replace them with supplier-approved photos once you choose the actual products.
